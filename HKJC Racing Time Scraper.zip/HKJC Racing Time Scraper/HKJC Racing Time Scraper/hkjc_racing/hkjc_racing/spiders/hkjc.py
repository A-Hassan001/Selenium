import csv
import time
from collections import OrderedDict

from scrapy import Spider, Request, Selector, signals
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver import Chrome
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager


class HkjcSpider(Spider):
    name = 'hkjc'
    base_url = 'https://racing.hkjc.com/'
    start_urls = [base_url]

    custom_settings = {
        'CONCURRENT_REQUESTS': 8,
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.racing_urls = self.get_racing_urls_from_file()
        options = Options()
        options.add_argument("--start-maximized")
        self.driver = Chrome(service=Service(ChromeDriverManager().install()),options=options)
        self.driver.maximize_window()

        self.items = []


    def parse(self, response, **kwargs):
        racing_url = self.racing_urls.pop(0)
        self.driver.get(racing_url)
        time.sleep(5)

        sel = Selector(text=self.driver.page_source)
        item = self.get_item(sel)
        self.items.append(item)

        yield item

        try:
            other_races_urls = [race.get_attribute('href') for race in
                                self.driver.find_elements(By.CSS_SELECTOR, '.top_races table tbody tr td a')]
        except AttributeError:
            other_races_urls = []

        for race_url in other_races_urls:
            self.driver.get(race_url)
            time.sleep(5)

            sel = Selector(text=self.driver.page_source)
            item = self.get_item(sel)
            self.items.append(item)

            yield item

    def get_item(self, response_sel):
        item = OrderedDict()

        item['Race Number'] = response_sel.css('.race_tab .bg_blue td ::text').re_first(r'\((\d+)\)', '')
        item['Time'] = response_sel.css('tr:contains("Time :") td:last-child ::text').re_first(r'[(](.*)[)]', '').replace(':', '.') or response_sel.css('tr:contains("時間 :") td:last-child ::text').re_first(r'[(](.*)[)]', '').replace(':', '.')

        sectional_times = response_sel.css('tr:contains("Sectional Time :") td.f_tac') or response_sel.css('tr:contains("分段時間 :") td.f_tac') or []

        for index, td in enumerate(sectional_times):
            item[f'Sectional Time{index+1}'] = td.css('::text').get('').strip()

        return item

    def get_racing_urls_from_file(self):
        with open('input/racing_urls.txt', mode='r', encoding='utf-8') as urls_file:
            return [url.strip() for url in urls_file.readlines() if url.strip()]

    def is_exists(self, css_selector='', xpath='', timeout=30):
        try:
            if xpath:
                WebDriverWait(self.driver, timeout=timeout).until(
                    EC.presence_of_element_located((By.XPATH, xpath)))

            else:
                WebDriverWait(self.driver, timeout=timeout).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, css_selector)))

            return True  # success

        except TimeoutException:
            return False  # fail

    def write_items_to_file(self):
        columns = []

        for item in self.items:
            for key in item.keys():
                if key in columns:
                    continue

                columns.append(key)

        with open('output/HKJC Racing Times.csv', mode='w', newline='', encoding='utf-8') as csv_file:
            csv_writer = csv.writer(csv_file, delimiter=',')

            csv_writer.writerow(columns)

            for item in self.items:
                csv_writer.writerow([item.get(col) for col in columns])

        self.logger.debug(f'\n{len(self.items)} rows Written to file\n')

    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        spider = super(HkjcSpider, cls).from_crawler(crawler, *args, **kwargs)
        crawler.signals.connect(spider.spider_idle, signal=signals.spider_idle)
        return spider

    def spider_idle(self):
        if not self.racing_urls:
            self.write_items_to_file()
            return

        self.crawler.engine.crawl(Request(url=self.base_url,
                                          callback=self.parse, dont_filter=True,
                                          meta={'handle_httpstatus_all': True}), self)

    def close(spider, reason):
        spider.driver.close()
        spider.driver.quit()
